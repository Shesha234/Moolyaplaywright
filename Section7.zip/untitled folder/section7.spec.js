import { test, expect } from '@playwright/test';
import fs from 'fs';

if (!fs.existsSync('screenshots')) fs.mkdirSync('screenshots');

test('Visit Playwright site and take screenshot', async ({ page }) => {
  await page.goto('https://playwright.dev/');
  await page.click('text=Get Started');
  await page.screenshot({ path: 'screenshots/playwright-home.png', fullPage: true });
  await expect(page).toHaveTitle(/Playwright/);
});
